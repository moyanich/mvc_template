
--
-- Indexes for dumped tables
--

--
-- Indexes for table `calender`
--
ALTER TABLE `calender`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `td_ymd_idx` (`year`,`month`,`day`),
  ADD UNIQUE KEY `td_dbdate_idx` (`db_date`);

--
-- Indexes for table `tblactivitylog`
--
ALTER TABLE `tblactivitylog`
  ADD PRIMARY KEY (`idLog`);

--
-- Indexes for table `tblAddresses`
--
ALTER TABLE `tblAddresses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblContractPeriod`
--
ALTER TABLE `tblContractPeriod`
  ADD PRIMARY KEY (`idEmployeeContractPeriod`),
  ADD KEY `idContractCode_fk_idx` (`idContractType_fk`),
  ADD KEY `idEmployee_fk_idx` (`idEmployee_fk`);

--
-- Indexes for table `tblcontracttype`
--
ALTER TABLE `tblcontracttype`
  ADD PRIMARY KEY (`idContractCode`),
  ADD UNIQUE KEY `idContractCode_UNIQUE` (`idContractCode`);

--
-- Indexes for table `tbldepartments`
--
ALTER TABLE `tbldepartments`
  ADD PRIMARY KEY (`iddept`,`deptCode`),
  ADD UNIQUE KEY `deptName` (`deptName`),
  ADD UNIQUE KEY `deptCode_UNIQUE` (`deptCode`);

--
-- Indexes for table `tblDeptManager`
--
ALTER TABLE `tblDeptManager`
  ADD PRIMARY KEY (`dept_no`,`emp_no`);

--
-- Indexes for table `tblDeptSupervisor`
--
ALTER TABLE `tblDeptSupervisor`
  ADD PRIMARY KEY (`dep_no`,`emp_no`);

--
-- Indexes for table `tblEmail`
--
ALTER TABLE `tblEmail`
  ADD PRIMARY KEY (`idEmail`),
  ADD UNIQUE KEY `email_address_UNIQUE` (`email_address`);

--
-- Indexes for table `tblEmployeeEmail`
--
ALTER TABLE `tblEmployeeEmail`
  ADD PRIMARY KEY (`idEmail`,`emp_no`),
  ADD UNIQUE KEY `email_address_UNIQUE` (`email_address`);

--
-- Indexes for table `tblemployees`
--
ALTER TABLE `tblemployees`
  ADD PRIMARY KEY (`eid`,`emp_no`),
  ADD UNIQUE KEY `idEmployee_UNIQUE` (`eid`),
  ADD UNIQUE KEY `emp_no_UNIQUE` (`emp_no`),
  ADD UNIQUE KEY `nis_UNIQUE` (`nis`),
  ADD UNIQUE KEY `trn_UNIQUE` (`trn`),
  ADD KEY `first_name` (`first_name`),
  ADD KEY `last_name` (`last_name`);

--
-- Indexes for table `tblleaveperiod`
--
ALTER TABLE `tblleaveperiod`
  ADD PRIMARY KEY (`idleave`),
  ADD KEY `idleave_type_fk` (`idleave_type_fk`),
  ADD KEY `idEmployee_fk_idx` (`idEmployee_fk`);

--
-- Indexes for table `tblleavetype`
--
ALTER TABLE `tblleavetype`
  ADD PRIMARY KEY (`id_leave_type`),
  ADD UNIQUE KEY `leave_type_code_UNIQUE` (`leave_type_code`);

--
-- Indexes for table `tblparishes`
--
ALTER TABLE `tblparishes`
  ADD PRIMARY KEY (`idParishes`);

--
-- Indexes for table `tblPhoneNumbers`
--
ALTER TABLE `tblPhoneNumbers`
  ADD PRIMARY KEY (`id`,`eid_fk`),
  ADD KEY `eid_fk_idx` (`eid_fk`);

--
-- Indexes for table `tblrole`
--
ALTER TABLE `tblrole`
  ADD PRIMARY KEY (`role_id`,`role_name`),
  ADD UNIQUE KEY `role_name_UNIQUE` (`role_name`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD KEY `role_id_fk_idx` (`usergroup`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tblactivitylog`
--
ALTER TABLE `tblactivitylog`
  MODIFY `idLog` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tblAddresses`
--
ALTER TABLE `tblAddresses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbldepartments`
--
ALTER TABLE `tbldepartments`
  MODIFY `iddept` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tblEmail`
--
ALTER TABLE `tblEmail`
  MODIFY `idEmail` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tblEmployeeEmail`
--
ALTER TABLE `tblEmployeeEmail`
  MODIFY `idEmail` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tblemployees`
--
ALTER TABLE `tblemployees`
  MODIFY `eid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tblparishes`
--
ALTER TABLE `tblparishes`
  MODIFY `idParishes` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `tblPhoneNumbers`
--
ALTER TABLE `tblPhoneNumbers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tblrole`
--
ALTER TABLE `tblrole`
  MODIFY `role_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tblPhoneNumbers`
--
ALTER TABLE `tblPhoneNumbers`
  ADD CONSTRAINT `eid_fk` FOREIGN KEY (`eid_fk`) REFERENCES `tblemployees` (`eid`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `usergroup` FOREIGN KEY (`usergroup`) REFERENCES `tblrole` (`role_id`) ON DELETE SET NULL ON UPDATE CASCADE;
