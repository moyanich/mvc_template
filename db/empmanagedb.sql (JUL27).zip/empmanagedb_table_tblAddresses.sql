
-- --------------------------------------------------------

--
-- Table structure for table `tblAddresses`
--

CREATE TABLE `tblAddresses` (
  `id` int(11) NOT NULL,
  `emp_no` varchar(45) DEFAULT NULL,
  `parish_id` int(11) DEFAULT NULL,
  `address` varchar(45) DEFAULT NULL,
  `city` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
