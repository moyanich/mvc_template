
-- --------------------------------------------------------

--
-- Table structure for table `tblContractPeriod`
--

CREATE TABLE `tblContractPeriod` (
  `idEmployeeContractPeriod` int(5) NOT NULL,
  `start_employment` date DEFAULT NULL,
  `end_employment` date DEFAULT NULL,
  `idContractType_fk` varchar(10) DEFAULT NULL,
  `idEmployee_fk` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
