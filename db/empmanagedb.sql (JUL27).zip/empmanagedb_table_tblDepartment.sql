
-- --------------------------------------------------------

--
-- Table structure for table `tblDepartment`
--

CREATE TABLE `tblDepartment` (
  `deptID` char(5) NOT NULL,
  `deptName` varchar(45) NOT NULL,
  `creation_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tblDepartment`
--

INSERT INTO `tblDepartment` (`deptID`, `deptName`, `creation_date`) VALUES
('dep1', 'Marketing', '2020-07-27 21:42:49'),
('dep2', 'Finance', '2020-07-27 21:42:49'),
('dep3', 'Human Resources', '2020-07-27 21:42:49'),
('dep4', 'Production', '2020-07-27 21:42:49'),
('dep5', 'Development', '2020-07-27 21:42:49'),
('dep6', 'Quality Management', '2020-07-27 21:42:49'),
('dep7', 'Sales', '2020-07-27 21:42:49'),
('dep8', 'Research', '2020-07-27 21:42:49'),
('dep9', 'Customer Service', '2020-07-27 21:42:49');
