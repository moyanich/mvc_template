
-- --------------------------------------------------------

--
-- Table structure for table `tblDeptManager`
--

CREATE TABLE `tblDeptManager` (
  `dept_no` int(11) NOT NULL,
  `emp_no` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
