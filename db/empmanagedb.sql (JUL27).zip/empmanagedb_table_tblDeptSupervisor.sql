
-- --------------------------------------------------------

--
-- Table structure for table `tblDeptSupervisor`
--

CREATE TABLE `tblDeptSupervisor` (
  `dep_no` int(11) NOT NULL,
  `emp_no` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tblDeptSupervisor`
--

INSERT INTO `tblDeptSupervisor` (`dep_no`, `emp_no`) VALUES
(1, 54),
(3, 54);
