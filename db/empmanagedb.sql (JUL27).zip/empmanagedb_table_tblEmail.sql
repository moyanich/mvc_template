
-- --------------------------------------------------------

--
-- Table structure for table `tblEmail`
--

CREATE TABLE `tblEmail` (
  `idEmail` int(11) NOT NULL,
  `email_address` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
