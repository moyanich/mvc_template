
-- --------------------------------------------------------

--
-- Table structure for table `tblEmployeeEmail`
--

CREATE TABLE `tblEmployeeEmail` (
  `idEmail` int(11) NOT NULL,
  `eid_fk` int(11) NOT NULL,
  `email_address` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
