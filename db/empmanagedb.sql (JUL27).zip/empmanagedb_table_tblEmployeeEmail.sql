
-- --------------------------------------------------------

--
-- Table structure for table `tblEmployeeEmail`
--

CREATE TABLE `tblEmployeeEmail` (
  `idEmail` int(11) NOT NULL,
  `emp_no` varchar(11) NOT NULL,
  `email_address` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
