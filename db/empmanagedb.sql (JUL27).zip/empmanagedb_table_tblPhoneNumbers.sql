
-- --------------------------------------------------------

--
-- Table structure for table `tblPhoneNumbers`
--

CREATE TABLE `tblPhoneNumbers` (
  `id` int(11) NOT NULL,
  `eid_fk` int(11) NOT NULL,
  `phone_no` varchar(12) NOT NULL,
  `phone_type` varchar(45) DEFAULT NULL COMMENT 'Home\nCell\nFax\nWork\nMobile'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tblPhoneNumbers`
--

INSERT INTO `tblPhoneNumbers` (`id`, `eid_fk`, `phone_no`, `phone_type`) VALUES
(1, 1, '471 815 4330', 'Cellphone'),
(2, 4, '671 615 5555', 'Landline'),
(5, 1, '510 868 2704', 'Cellphone');
