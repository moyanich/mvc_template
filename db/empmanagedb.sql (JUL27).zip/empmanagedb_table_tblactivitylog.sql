
-- --------------------------------------------------------

--
-- Table structure for table `tblactivitylog`
--

CREATE TABLE `tblactivitylog` (
  `idLog` int(11) NOT NULL,
  `iduser_fk` int(11) DEFAULT NULL,
  `log_details` varchar(155) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
