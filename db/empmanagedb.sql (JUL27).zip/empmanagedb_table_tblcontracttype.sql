
-- --------------------------------------------------------

--
-- Table structure for table `tblcontracttype`
--

CREATE TABLE `tblcontracttype` (
  `idContractCode` varchar(10) NOT NULL,
  `contract_description` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tblcontracttype`
--

INSERT INTO `tblcontracttype` (`idContractCode`, `contract_description`) VALUES
('CT', 'Contract'),
('FT', 'Full-time'),
('PT', 'Part-time');
