
-- --------------------------------------------------------

--
-- Table structure for table `tbldepartments`
--

CREATE TABLE `tbldepartments` (
  `dept_id` char(6) COLLATE utf8_unicode_ci NOT NULL,
  `deptName` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `creationDate` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tbldepartments`
--

INSERT INTO `tbldepartments` (`dept_id`, `deptName`, `creationDate`) VALUES
('B01', 'Bindery', '2020-07-25 19:01:58'),
('B02', 'Accounts', '2020-07-25 19:01:58'),
('B03', 'Commercial Office', '2020-07-27 15:38:53'),
('B06', 'Information Technology', '2020-07-27 16:42:03');
