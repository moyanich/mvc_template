
-- --------------------------------------------------------

--
-- Table structure for table `tbldepartments`
--

CREATE TABLE `tbldepartments` (
  `iddept` int(11) NOT NULL,
  `deptCode` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `deptName` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `deptManager` varchar(11) COLLATE utf8_unicode_ci DEFAULT NULL,
  `deptSupervisor` varchar(11) COLLATE utf8_unicode_ci DEFAULT NULL,
  `creationDate` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tbldepartments`
--

INSERT INTO `tbldepartments` (`iddept`, `deptCode`, `deptName`, `deptManager`, `deptSupervisor`, `creationDate`) VALUES
(1, 'B01', 'Bindery', NULL, NULL, '2020-07-25 19:01:58'),
(2, 'B02', 'Accounts', NULL, NULL, '2020-07-25 19:01:58'),
(3, 'B03', 'Commercial Office', NULL, NULL, '2020-07-27 15:38:53'),
(4, 'B06', 'Information Technology', NULL, NULL, '2020-07-27 16:42:03');
