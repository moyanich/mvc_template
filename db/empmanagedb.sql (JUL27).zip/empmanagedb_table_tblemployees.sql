
-- --------------------------------------------------------

--
-- Table structure for table `tblemployees`
--

CREATE TABLE `tblemployees` (
  `eid` int(11) NOT NULL,
  `emp_no` varchar(11) COLLATE utf8_unicode_ci NOT NULL,
  `first_name` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `middle_name` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `last_name` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `hire_date` date DEFAULT NULL,
  `gender` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `nis` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `trn` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `job` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `deptno` int(11) DEFAULT NULL,
  `emp_phone_fk` int(11) DEFAULT NULL,
  `idParishes_fk` int(5) DEFAULT NULL,
  `supervisor_id` varchar(11) COLLATE utf8_unicode_ci DEFAULT NULL,
  `manager_id` varchar(11) COLLATE utf8_unicode_ci DEFAULT NULL,
  `empPhoto` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tblemployees`
--

INSERT INTO `tblemployees` (`eid`, `emp_no`, `first_name`, `middle_name`, `last_name`, `hire_date`, `gender`, `dob`, `nis`, `trn`, `job`, `deptno`, `emp_phone_fk`, `idParishes_fk`, `supervisor_id`, `manager_id`, `empPhoto`) VALUES
(1, 'B290', 'Mary', 'S', 'Chold', '0000-00-00', '', '0000-00-00', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(4, 'B291', 'Tome', 'A', 'Scold', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
