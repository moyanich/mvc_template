
-- --------------------------------------------------------

--
-- Table structure for table `tblpasswordreset`
--

CREATE TABLE `tblpasswordreset` (
  `pid` int(11) NOT NULL,
  `user_id_fk` int(11) NOT NULL,
  `reset_token` varchar(255) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
