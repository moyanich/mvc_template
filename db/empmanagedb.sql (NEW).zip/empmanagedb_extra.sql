
--
-- Indexes for dumped tables
--

--
-- Indexes for table `calender`
--
ALTER TABLE `calender`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `td_ymd_idx` (`year`,`month`,`day`),
  ADD UNIQUE KEY `td_dbdate_idx` (`db_date`);

--
-- Indexes for table `tblactivitylog`
--
ALTER TABLE `tblactivitylog`
  ADD PRIMARY KEY (`idLog`);

--
-- Indexes for table `tblContractPeriod`
--
ALTER TABLE `tblContractPeriod`
  ADD PRIMARY KEY (`idEmployeeContractPeriod`),
  ADD KEY `idContractCode_fk_idx` (`idContractType_fk`),
  ADD KEY `idEmployee_fk_idx` (`idEmployee_fk`);

--
-- Indexes for table `tblcontracttype`
--
ALTER TABLE `tblcontracttype`
  ADD PRIMARY KEY (`idContractCode`),
  ADD UNIQUE KEY `idContractCode_UNIQUE` (`idContractCode`);

--
-- Indexes for table `tbldepartments`
--
ALTER TABLE `tbldepartments`
  ADD PRIMARY KEY (`iddept`),
  ADD UNIQUE KEY `deptName` (`deptName`),
  ADD KEY `superid` (`deptSupervisor`),
  ADD KEY `managerid` (`deptManager`);

--
-- Indexes for table `tblemployees`
--
ALTER TABLE `tblemployees`
  ADD PRIMARY KEY (`idEmployee`,`emp_no`),
  ADD UNIQUE KEY `idEmployee_UNIQUE` (`idEmployee`),
  ADD UNIQUE KEY `nis_UNIQUE` (`nis`),
  ADD UNIQUE KEY `trn_UNIQUE` (`trn`),
  ADD UNIQUE KEY `emp_no_UNIQUE` (`emp_no`),
  ADD KEY `idParishes_fk_idx` (`idParishes_fk`),
  ADD KEY `supervisor_id` (`supervisor_id`),
  ADD KEY `manager_id` (`manager_id`),
  ADD KEY `idept` (`deptno`);

--
-- Indexes for table `tblleaveperiod`
--
ALTER TABLE `tblleaveperiod`
  ADD PRIMARY KEY (`idleave`),
  ADD KEY `idleave_type_fk` (`idleave_type_fk`),
  ADD KEY `idEmployee_fk_idx` (`idEmployee_fk`);

--
-- Indexes for table `tblleavetype`
--
ALTER TABLE `tblleavetype`
  ADD PRIMARY KEY (`id_leave_type`),
  ADD UNIQUE KEY `leave_type_code_UNIQUE` (`leave_type_code`);

--
-- Indexes for table `tblparishes`
--
ALTER TABLE `tblparishes`
  ADD PRIMARY KEY (`idParishes`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tblactivitylog`
--
ALTER TABLE `tblactivitylog`
  MODIFY `idLog` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbldepartments`
--
ALTER TABLE `tbldepartments`
  MODIFY `iddept` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tblemployees`
--
ALTER TABLE `tblemployees`
  MODIFY `idEmployee` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=104;

--
-- AUTO_INCREMENT for table `tblparishes`
--
ALTER TABLE `tblparishes`
  MODIFY `idParishes` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tbldepartments`
--
ALTER TABLE `tbldepartments`
  ADD CONSTRAINT `managerid` FOREIGN KEY (`deptManager`) REFERENCES `tblemployees` (`emp_no`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `superid` FOREIGN KEY (`deptSupervisor`) REFERENCES `tblemployees` (`emp_no`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `tblemployees`
--
ALTER TABLE `tblemployees`
  ADD CONSTRAINT `idept` FOREIGN KEY (`deptno`) REFERENCES `tbldepartments` (`iddept`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `manager_id` FOREIGN KEY (`manager_id`) REFERENCES `tblemployees` (`emp_no`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `parish_fk` FOREIGN KEY (`idParishes_fk`) REFERENCES `tblparishes` (`idParishes`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `supervisor_id` FOREIGN KEY (`supervisor_id`) REFERENCES `tblemployees` (`emp_no`) ON DELETE SET NULL ON UPDATE CASCADE;
