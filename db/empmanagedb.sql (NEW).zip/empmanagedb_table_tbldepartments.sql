
-- --------------------------------------------------------

--
-- Table structure for table `tbldepartments`
--

CREATE TABLE `tbldepartments` (
  `iddept` int(11) NOT NULL,
  `deptName` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `deptManager` varchar(11) COLLATE utf8_unicode_ci DEFAULT NULL,
  `deptSupervisor` varchar(11) COLLATE utf8_unicode_ci DEFAULT NULL,
  `creationDate` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tbldepartments`
--

INSERT INTO `tbldepartments` (`iddept`, `deptName`, `deptManager`, `deptSupervisor`, `creationDate`) VALUES
(1, 'Bindery', NULL, NULL, '2020-07-25 19:01:58'),
(2, 'Accounts', NULL, NULL, '2020-07-25 19:01:58');
