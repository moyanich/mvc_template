
-- --------------------------------------------------------

--
-- Table structure for table `tblemployees`
--

CREATE TABLE `tblemployees` (
  `idEmployee` int(11) NOT NULL,
  `emp_no` varchar(11) COLLATE utf8_unicode_ci NOT NULL,
  `first_name` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `middle_name` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `last_name` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `hire_date` date NOT NULL,
  `gender` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `dob` date NOT NULL,
  `nis` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `trn` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `job` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `deptno` int(11) DEFAULT NULL,
  `phone` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email_address` varchar(55) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `city` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `idParishes_fk` int(5) DEFAULT NULL,
  `other_address_details` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `supervisor_id` varchar(11) COLLATE utf8_unicode_ci DEFAULT NULL,
  `manager_id` varchar(11) COLLATE utf8_unicode_ci DEFAULT NULL,
  `empPhoto` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tblemployees`
--

INSERT INTO `tblemployees` (`idEmployee`, `emp_no`, `first_name`, `middle_name`, `last_name`, `hire_date`, `gender`, `dob`, `nis`, `trn`, `job`, `deptno`, `phone`, `email_address`, `address`, `city`, `idParishes_fk`, `other_address_details`, `supervisor_id`, `manager_id`, `empPhoto`) VALUES
(54, '52-5003666', 'Sonnie', '43.132.73.100', 'Riley', '2006-07-03', 'Male', '2001-06-20', '293-31-0967', '320-56-7221', 'Social Worker', 2, '471 815 4330', 'sriley1@delicious.com', '673 Maywood Junction', 'La Cruz de Río Grande', 4, NULL, NULL, NULL, NULL),
(55, '25-9515744', 'Brennan', '14.106.161.116', 'Tambling', '2000-06-03', 'Male', '1994-03-22', '411-83-8537', '752-50-2971', 'Budget/Accounting Analyst III', 2, '210 606 3462', 'btambling2@phpbb.com', '80 Atwood Crossing', 'Juzhen', 7, NULL, NULL, NULL, NULL),
(58, '63-2984238', 'Delia', '136.215.149.66', 'Churchill', '2002-01-09', 'Female', '1994-01-07', '486-97-7046', '265-93-5160', 'Graphic Designer', 1, '719 494 9914', 'dchurchill5@mit.edu', '296 Warrior Way', 'Ábrego', 9, NULL, NULL, NULL, NULL),
(60, '79-1383024', 'Korey', '184.29.230.239', 'Bearsmore', '2001-02-10', 'Male', '1990-08-27', '546-74-7313', '223-36-2218', 'Compensation Analyst', 1, '307 914 5589', 'kbearsmore7@google.com.br', '750 Hintze Hill', 'Kamensk-Ural’skiy', 1, NULL, NULL, NULL, NULL),
(62, '41-3164726', 'Benjamen', '101.176.186.168', 'Belfield', '2020-05-05', 'Male', '2006-11-05', '718-20-3404', '510-54-0129', 'Electrical Engineer', 2, '187 995 6713', 'bbelfield9@de.vu', '85 Green Ridge Alley', 'Pijao', 7, NULL, NULL, NULL, NULL),
(63, '04-9723654', 'Say', '41.206.57.32', 'Petriello', '2017-02-14', 'Male', '2000-10-28', '122-11-8323', '377-93-9268', 'Human Resources Manager', 1, '425 572 5634', 'spetrielloa@cdc.gov', '21676 Summerview Pass', 'Borlänge', 8, NULL, NULL, NULL, NULL),
(64, '50-0039245', 'Emiline', '88.170.71.27', 'Vignaux', '2003-10-29', 'Female', '1977-12-16', '742-97-1287', '762-02-4643', 'Analyst Programmer', 2, '791 480 6584', 'evignauxb@fc2.com', '4179 Hagan Junction', 'Strabychovo', 12, NULL, NULL, NULL, NULL),
(65, '65-2901121', 'Alaster', '139.62.163.164', 'Newtown', '2005-11-20', 'Male', '2005-06-10', '108-20-6971', '736-97-4976', 'Marketing Manager', 2, '626 469 3823', 'anewtownc@soundcloud.com', '863 Darwin Hill', 'Chemerivtsi', 2, NULL, NULL, NULL, NULL),
(68, '66-7320457', 'Cobby', '210.219.28.157', 'Penn', '2010-09-09', 'Male', '2009-09-29', '616-51-8801', '267-89-9481', 'Chief Design Engineer', 2, '951 513 6127', 'cpennf@mozilla.com', '21 Hauk Way', 'Długosiodło', 14, NULL, NULL, NULL, NULL),
(69, '65-0940536', 'Adorne', '147.131.104.226', 'McRonald', '2001-03-23', 'Female', '1971-08-14', '628-19-4396', '221-46-6202', 'Professor', 1, '519 673 0231', 'amcronaldg@independent.co.uk', '859 Aberg Trail', 'Zudun', 5, NULL, NULL, NULL, NULL),
(70, '36-4485428', 'Fidelio', '74.68.56.195', 'Cahill', '2019-05-30', 'Male', '2012-09-11', '116-04-7721', '224-87-9034', 'Financial Advisor', 1, '296 119 4872', 'fcahillh@alexa.com', '51 Charing Cross Avenue', 'Ljungskile', 13, NULL, NULL, NULL, NULL),
(71, '52-8568182', 'Loy', '139.36.230.227', 'Sedgemond', '2001-09-21', 'Male', '1980-08-02', '516-54-7704', '570-85-8846', 'Human Resources Manager', 1, '446 220 0844', 'lsedgemondi@odnoklassniki.ru', '823 Straubel Alley', 'Zimmi', 13, NULL, NULL, NULL, NULL),
(72, '46-5724787', 'Filippa', '44.88.190.168', 'Eckersley', '2009-09-07', 'Female', '1999-12-11', '877-75-9624', '131-05-1843', 'Research Assistant II', 1, '265 339 6684', 'feckersleyj@ocn.ne.jp', '818 Ronald Regan Way', 'Khāngāh Dogrān', 13, NULL, NULL, NULL, NULL),
(73, '49-6015478', 'Danyelle', '181.33.8.162', 'Skittreal', '2003-09-30', 'Female', '2000-08-06', '369-14-0588', '685-40-2355', 'Product Engineer', 2, '583 984 4386', 'dskittrealk@blogger.com', '7 International Trail', 'Karlovy Vary', 6, NULL, NULL, NULL, NULL),
(74, '64-0980432', 'Dion', '130.90.175.139', 'Thoms', '2003-04-21', 'Female', '1970-11-15', '477-79-1002', '427-55-2558', 'Quality Control Specialist', 1, '428 941 1423', 'dthomsl@technorati.com', '00 Namekagon Terrace', 'Bodĭ', 8, NULL, NULL, NULL, NULL),
(75, '76-1790174', 'Barrie', '207.227.137.170', 'Hawkwood', '2011-09-19', 'Female', '1978-07-21', '661-82-9109', '665-18-5161', 'Structural Analysis Engineer', 1, '402 648 1038', 'bhawkwoodm@jiathis.com', '531 Goodland Terrace', 'Metu', 14, NULL, NULL, NULL, NULL),
(76, '16-8244969', 'Pascale', '147.135.41.20', 'Snowden', '2000-11-07', 'Male', '2001-07-22', '695-38-8546', '672-39-7596', 'Compensation Analyst', 1, '510 868 2704', 'psnowdenn@sina.com.cn', '834 Sachs Way', 'Przystajń', 11, NULL, NULL, NULL, NULL),
(77, '55-6342176', 'Jerrie', '39.8.178.230', 'Berrane', '2013-10-06', 'Female', '1978-04-30', '338-47-5753', '663-42-1796', 'Legal Assistant', 2, '154 972 4636', 'jberraneo@abc.net.au', '1 Warbler Alley', 'Myaydo', 1, NULL, NULL, NULL, NULL),
(80, '85-5413009', 'Barbara', '113.66.110.29', 'Stickens', '2006-08-03', 'Female', '1992-03-30', '154-36-7710', '207-99-8387', 'Recruiting Manager', 1, '188 947 1248', 'bstickensr@comsenz.com', '8 Dunning Pass', 'Colonia Mauricio José Troche', 2, NULL, NULL, NULL, NULL),
(81, '21-5364200', 'Dorolice', '214.224.49.117', 'Fownes', '2006-08-09', 'Female', '2014-05-02', '341-64-7178', '722-59-4272', 'Analog Circuit Design manager', 1, '148 847 0084', 'dfowness@japanpost.jp', '6153 Orin Hill', 'San Esteban', 5, NULL, NULL, NULL, NULL),
(82, '20-0834159', 'Lorin', '114.198.251.206', 'Lamblin', '2000-04-20', 'Male', '1989-12-15', '880-96-6857', '384-56-8153', 'Electrical Engineer', 1, '746 559 0325', 'llamblint@hugedomains.com', '19 Summer Ridge Drive', 'Weepanapi', 7, NULL, NULL, NULL, NULL),
(83, '39-8022552', 'Ailis', '72.130.59.222', 'Grady', '2006-10-08', 'Female', '2000-10-23', '354-75-1737', '539-51-0082', 'Junior Executive', 1, '582 511 3943', 'agradyu@npr.org', '04 Carpenter Parkway', 'Cabungan', 10, NULL, NULL, NULL, NULL),
(86, '46-0956425', 'Donny', '29.114.119.205', 'Vannucci', '2011-01-22', 'Male', '1970-12-07', '855-66-5872', '441-50-7153', 'Health Coach IV', 2, '350 189 0550', 'dvannuccix@nhs.uk', '29155 Melrose Alley', 'Cemplang', 9, NULL, NULL, NULL, NULL),
(93, '46-0404861', 'Baryram', '250.115.169.184', 'MacAlpyne', '2017-02-25', 'Male', '2018-03-02', '634-83-2145', '736-70-6348', 'Civil Engineer', 2, '350 944 9731', 'bmacalpyne14@sogou.com', '0 Bayside Alley', 'Leiden', 11, NULL, NULL, NULL, NULL),
(95, '70-3537073', 'Essy', '105.64.17.19', 'Chaffer', '2007-06-12', 'Female', '1994-05-12', '728-44-1926', '130-65-9513', 'Accounting Assistant II', 2, '205 715 0587', 'echaffer16@microsoft.com', '57 Bobwhite Place', 'Catanduva', 2, NULL, NULL, NULL, NULL),
(97, '50-8129349', 'Fitz', '224.144.59.248', 'Gimeno', '2003-07-27', 'Male', '1973-08-17', '512-76-6544', '335-69-7388', 'Speech Pathologist', 2, '953 246 8845', 'fgimeno18@aboutads.info', '1140 Walton Way', 'Isanlu Itedoijowa', 13, NULL, NULL, NULL, NULL),
(98, '40-2683996', 'Nolan', '1.73.241.249', 'Borrowman', '2010-03-27', 'Male', '2011-09-23', '526-05-1698', '750-18-4546', 'Nurse', 1, '139 210 8834', 'nborrowman19@theatlantic.com', '190 Almo Parkway', 'Hushan', 3, NULL, NULL, NULL, NULL),
(100, '08-0226688', 'Chaddy', '42.186.250.97', 'Lippingwell', '2017-02-09', 'Male', '1986-01-29', '792-03-2610', '807-35-7755', 'Geologist III', 2, '690 107 2257', 'clippingwell1b@webs.com', '25 Lake View Lane', 'Banayoyo', 6, NULL, NULL, NULL, NULL);
