
-- --------------------------------------------------------

--
-- Table structure for table `tblleaveperiod`
--

CREATE TABLE `tblleaveperiod` (
  `idleave` int(11) NOT NULL,
  `idleave_type_fk` int(11) DEFAULT NULL,
  `leave_allowance` int(11) DEFAULT NULL,
  `leave_expires` date DEFAULT NULL,
  `leave_cumulative_days_taken` int(11) DEFAULT NULL,
  `leave_notes` varchar(155) COLLATE utf8_unicode_ci DEFAULT NULL,
  `leave_from_date` date DEFAULT NULL,
  `leave_to_date` date DEFAULT NULL,
  `date_marked_on` timestamp NULL DEFAULT NULL,
  `idEmployee_fk` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
