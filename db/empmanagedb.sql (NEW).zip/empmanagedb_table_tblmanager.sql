
-- --------------------------------------------------------

--
-- Table structure for table `tblmanager`
--

CREATE TABLE `tblmanager` (
  `idDeptManager` int(11) NOT NULL,
  `idDepartment_fk` int(11) DEFAULT NULL,
  `emp_no_fk` varchar(11) DEFAULT NULL,
  `from_date` date DEFAULT NULL,
  `to_date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
