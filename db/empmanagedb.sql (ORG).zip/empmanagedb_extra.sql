
--
-- Indexes for dumped tables
--

--
-- Indexes for table `calendar`
--
ALTER TABLE `calendar`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `td_ymd_idx` (`year`,`month`,`day`),
  ADD UNIQUE KEY `td_dbdate_idx` (`db_date`);

--
-- Indexes for table `tblActivityLog`
--
ALTER TABLE `tblActivityLog`
  ADD PRIMARY KEY (`idLog`);

--
-- Indexes for table `tblContractType`
--
ALTER TABLE `tblContractType`
  ADD PRIMARY KEY (`idContractCode`),
  ADD UNIQUE KEY `idContractCode_UNIQUE` (`idContractCode`);

--
-- Indexes for table `tblDepartment`
--
ALTER TABLE `tblDepartment`
  ADD PRIMARY KEY (`idDept`),
  ADD UNIQUE KEY `department_name_UNIQUE` (`deptName`);

--
-- Indexes for table `tblDepartmentManager`
--
ALTER TABLE `tblDepartmentManager`
  ADD PRIMARY KEY (`idDeptManager`),
  ADD KEY `idDepartment_fk_idx` (`idDepartment_fk`);

--
-- Indexes for table `tblEmployeeContractPeriod`
--
ALTER TABLE `tblEmployeeContractPeriod`
  ADD PRIMARY KEY (`idEmployeeContractPeriod`),
  ADD KEY `idContractCode_fk_idx` (`idContractType_fk`),
  ADD KEY `idEmployee_fk_idx` (`idEmployee_fk`);

--
-- Indexes for table `tblEmployees`
--
ALTER TABLE `tblEmployees`
  ADD PRIMARY KEY (`idEmployee`,`emp_no`),
  ADD UNIQUE KEY `idEmployee_UNIQUE` (`idEmployee`),
  ADD UNIQUE KEY `nis_UNIQUE` (`nis`),
  ADD UNIQUE KEY `trn_UNIQUE` (`trn`),
  ADD UNIQUE KEY `emp_no_UNIQUE` (`emp_no`),
  ADD KEY `idParishes_fk_idx` (`idParishes_fk`),
  ADD KEY `idDepartment_fk_idx` (`idDepartment_fk`),
  ADD KEY `supervisor_id_idx` (`supervisor_id`);

--
-- Indexes for table `tblLeavePeriod`
--
ALTER TABLE `tblLeavePeriod`
  ADD PRIMARY KEY (`idleave`),
  ADD KEY `idleave_type_fk` (`idleave_type_fk`),
  ADD KEY `idEmployee_fk_idx` (`idEmployee_fk`);

--
-- Indexes for table `tblLeaveType`
--
ALTER TABLE `tblLeaveType`
  ADD PRIMARY KEY (`id_leave_type`),
  ADD UNIQUE KEY `leave_type_code_UNIQUE` (`leave_type_code`);

--
-- Indexes for table `tblParishes`
--
ALTER TABLE `tblParishes`
  ADD PRIMARY KEY (`idParishes`);

--
-- Indexes for table `tblRole`
--
ALTER TABLE `tblRole`
  ADD PRIMARY KEY (`role_id`),
  ADD UNIQUE KEY `role_id_UNIQUE` (`role_id`),
  ADD UNIQUE KEY `role_name_UNIQUE` (`role_name`);

--
-- Indexes for table `tblSupervisor`
--
ALTER TABLE `tblSupervisor`
  ADD PRIMARY KEY (`idSupervisor`);

--
-- Indexes for table `tblUserSession`
--
ALTER TABLE `tblUserSession`
  ADD PRIMARY KEY (`idsessions`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `email_UNIQUE` (`email`),
  ADD KEY `id_role_fk_idx` (`usergroup`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tblDepartment`
--
ALTER TABLE `tblDepartment`
  MODIFY `idDept` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `tblDepartmentManager`
--
ALTER TABLE `tblDepartmentManager`
  MODIFY `idDeptManager` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tblEmployees`
--
ALTER TABLE `tblEmployees`
  MODIFY `idEmployee` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT for table `tblLeavePeriod`
--
ALTER TABLE `tblLeavePeriod`
  MODIFY `idleave` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tblLeaveType`
--
ALTER TABLE `tblLeaveType`
  MODIFY `id_leave_type` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tblParishes`
--
ALTER TABLE `tblParishes`
  MODIFY `idParishes` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `tblSupervisor`
--
ALTER TABLE `tblSupervisor`
  MODIFY `idSupervisor` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tblUserSession`
--
ALTER TABLE `tblUserSession`
  MODIFY `idsessions` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=131;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tblEmployeeContractPeriod`
--
ALTER TABLE `tblEmployeeContractPeriod`
  ADD CONSTRAINT `idContractCode_fk` FOREIGN KEY (`idContractType_fk`) REFERENCES `tblContractType` (`idContractCode`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tblEmployees`
--
ALTER TABLE `tblEmployees`
  ADD CONSTRAINT `idDepartment_fk` FOREIGN KEY (`idDepartment_fk`) REFERENCES `tblDepartment` (`idDept`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `idParishes_fk` FOREIGN KEY (`idParishes_fk`) REFERENCES `tblParishes` (`idParishes`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `tblLeavePeriod`
--
ALTER TABLE `tblLeavePeriod`
  ADD CONSTRAINT `idleave_type_fk` FOREIGN KEY (`idleave_type_fk`) REFERENCES `tblLeaveType` (`id_leave_type`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `id_role_fk` FOREIGN KEY (`usergroup`) REFERENCES `tblRole` (`role_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;
