
-- --------------------------------------------------------

--
-- Table structure for table `tblContractType`
--

CREATE TABLE `tblContractType` (
  `idContractCode` varchar(10) NOT NULL,
  `contract_description` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tblContractType`
--

INSERT INTO `tblContractType` (`idContractCode`, `contract_description`) VALUES
('CT', 'Contract'),
('FT', 'Full-time'),
('PT', 'Part-time');
