
-- --------------------------------------------------------

--
-- Table structure for table `tblDepartment`
--

CREATE TABLE `tblDepartment` (
  `idDept` int(11) NOT NULL,
  `deptName` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `deptCode` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `creationDate` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tblDepartment`
--

INSERT INTO `tblDepartment` (`idDept`, `deptName`, `deptCode`, `creationDate`) VALUES
(1, 'Commercial Office', 'COMMERICAL', '2020-07-23 20:51:09'),
(2, 'Prepress', 'PRESS', '2020-07-23 20:51:45'),
(3, 'Bindery', 'BIND', '2020-07-23 20:51:54'),
(4, 'Accounts', 'ACC', '2020-07-24 20:39:52'),
(5, 'Information Technology', 'IT', '2020-07-24 20:40:57'),
(6, 'SAM', 'SAMI', '2020-07-24 20:42:00'),
(7, 'smokeqs', 'fsvsvs', '2020-07-24 20:43:01');
