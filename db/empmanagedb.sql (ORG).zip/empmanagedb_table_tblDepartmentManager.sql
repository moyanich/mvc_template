
-- --------------------------------------------------------

--
-- Table structure for table `tblDepartmentManager`
--

CREATE TABLE `tblDepartmentManager` (
  `idDeptManager` int(11) NOT NULL,
  `idDepartment_fk` int(11) DEFAULT NULL,
  `emp_no_fk` varchar(11) DEFAULT NULL,
  `from_date` date DEFAULT NULL,
  `to_date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tblDepartmentManager`
--

INSERT INTO `tblDepartmentManager` (`idDeptManager`, `idDepartment_fk`, `emp_no_fk`, `from_date`, `to_date`) VALUES
(1, 2, '1', NULL, NULL);
