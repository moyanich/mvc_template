
-- --------------------------------------------------------

--
-- Table structure for table `tblLeaveType`
--

CREATE TABLE `tblLeaveType` (
  `id_leave_type` int(11) NOT NULL,
  `leave_type_code` varchar(5) COLLATE utf8mb4_unicode_ci NOT NULL,
  `leave_type_description` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'sick, vacation'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
