
-- --------------------------------------------------------

--
-- Table structure for table `tblParishes`
--

CREATE TABLE `tblParishes` (
  `idParishes` int(5) NOT NULL,
  `parish_name` varchar(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tblParishes`
--

INSERT INTO `tblParishes` (`idParishes`, `parish_name`) VALUES
(1, 'Kingston'),
(2, 'St. Andrew'),
(3, 'Westmoreland'),
(4, 'Hanover'),
(5, 'Saint Elizabeth'),
(6, 'Trelawny'),
(7, 'Clarendon'),
(8, 'Manchester'),
(9, 'St. Ann'),
(10, 'St. Catherine'),
(11, 'St. Mary'),
(12, 'Portland'),
(13, 'St. Thomas'),
(14, 'St. James');
