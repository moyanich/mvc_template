
-- --------------------------------------------------------

--
-- Table structure for table `tblRole`
--

CREATE TABLE `tblRole` (
  `role_id` int(11) NOT NULL,
  `role_name` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tblRole`
--

INSERT INTO `tblRole` (`role_id`, `role_name`) VALUES
(1, 'Adminstrator'),
(4, 'New User'),
(3, 'Officer'),
(2, 'Super User');
