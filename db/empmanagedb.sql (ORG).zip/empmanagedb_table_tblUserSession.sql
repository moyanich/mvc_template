
-- --------------------------------------------------------

--
-- Table structure for table `tblUserSession`
--

CREATE TABLE `tblUserSession` (
  `idsessions` int(11) NOT NULL,
  `user_id_fk` int(11) NOT NULL,
  `session_token` varchar(255) NOT NULL,
  `session_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
