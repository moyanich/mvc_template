
-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `username` varchar(15) NOT NULL,
  `password` varchar(70) NOT NULL,
  `email` varchar(45) NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `deleted_at` datetime DEFAULT NULL,
  `usergroup` int(11) DEFAULT '3' COMMENT 'super_admin: 1, admin: 2, user: 3, unregistered: 4',
  `active` varchar(255) DEFAULT NULL,
  `resetToken` varchar(255) DEFAULT NULL,
  `resetComplete` varchar(255) DEFAULT 'No'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `username`, `password`, `email`, `created_at`, `modified_at`, `deleted_at`, `usergroup`, `active`, `resetToken`, `resetComplete`) VALUES
(129, 'admin', '$2y$12$5xzpSTpvn7ohLJPjTnxmw.MGh15AARjRSwCw.hZD.PXrn8cjT5qMy', 'xifotyby@mailinator.com', '2020-07-22 16:48:29', '2020-07-22 11:48:29', '2020-07-22 11:48:29', 1, NULL, NULL, 'No'),
(130, 'testuser', '$2y$12$tvia4Ehnw9Bzjr3NdTbQ4.B6zx8FUPjCkNgsfWuh9txMhQup5Cic6', 'zavohakoki@mailinator.com', '2020-07-22 18:02:46', '2020-07-22 13:02:46', '2020-07-22 13:02:46', 3, NULL, NULL, 'No');
