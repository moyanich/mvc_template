
--
-- Indexes for dumped tables
--

--
-- Indexes for table `tblContactNumbers`
--
ALTER TABLE `tblContactNumbers`
  ADD PRIMARY KEY (`phoneID`);

--
-- Indexes for table `tblDepartments`
--
ALTER TABLE `tblDepartments`
  ADD PRIMARY KEY (`deptID`),
  ADD UNIQUE KEY `deptName_UNIQUE` (`deptName`);

--
-- Indexes for table `tblEmailAddress`
--
ALTER TABLE `tblEmailAddress`
  ADD PRIMARY KEY (`emailID`);

--
-- Indexes for table `tblEmpContact`
--
ALTER TABLE `tblEmpContact`
  ADD PRIMARY KEY (`id`),
  ADD KEY `relEmpID_idx` (`relEmpID`),
  ADD KEY `relPhoneID_idx` (`relPhoneID`);

--
-- Indexes for table `tblEmpEmail`
--
ALTER TABLE `tblEmpEmail`
  ADD PRIMARY KEY (`id`),
  ADD KEY `relEmpID_idx` (`relEmpID`),
  ADD KEY `relEmailID_idx` (`relEmailID`);

--
-- Indexes for table `tblEmployees`
--
ALTER TABLE `tblEmployees`
  ADD PRIMARY KEY (`empID`),
  ADD UNIQUE KEY `id_UNIQUE` (`id`),
  ADD UNIQUE KEY `trn_UNIQUE` (`trn`),
  ADD UNIQUE KEY `nis_UNIQUE` (`nis`),
  ADD KEY `deptID_fk_idx` (`relDeptID`),
  ADD KEY `relGender_idx` (`relGender`);

--
-- Indexes for table `tblGender`
--
ALTER TABLE `tblGender`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tblrole`
--
ALTER TABLE `tblrole`
  ADD PRIMARY KEY (`role_id`,`role_name`),
  ADD UNIQUE KEY `role_name_UNIQUE` (`role_name`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `username_UNIQUE` (`username`),
  ADD KEY `role_id_fk_idx` (`userRole`),
  ADD KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tblContactNumbers`
--
ALTER TABLE `tblContactNumbers`
  MODIFY `phoneID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tblEmailAddress`
--
ALTER TABLE `tblEmailAddress`
  MODIFY `emailID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tblEmpEmail`
--
ALTER TABLE `tblEmpEmail`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tblEmployees`
--
ALTER TABLE `tblEmployees`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tblGender`
--
ALTER TABLE `tblGender`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tblrole`
--
ALTER TABLE `tblrole`
  MODIFY `role_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tblEmpContact`
--
ALTER TABLE `tblEmpContact`
  ADD CONSTRAINT `relEmpID` FOREIGN KEY (`relEmpID`) REFERENCES `tblEmployees` (`empID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `relPhoneID` FOREIGN KEY (`relPhoneID`) REFERENCES `tblContactNumbers` (`phoneID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tblEmpEmail`
--
ALTER TABLE `tblEmpEmail`
  ADD CONSTRAINT `relEmailID` FOREIGN KEY (`relEmailID`) REFERENCES `tblEmailAddress` (`emailID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tblEmployees`
--
ALTER TABLE `tblEmployees`
  ADD CONSTRAINT `deptID_fk` FOREIGN KEY (`relDeptID`) REFERENCES `tblDepartments` (`deptID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `relGender` FOREIGN KEY (`relGender`) REFERENCES `tblGender` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tblemployees_ibfk_1` FOREIGN KEY (`empID`) REFERENCES `tblEmpEmail` (`relEmpID`);

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `usergroup` FOREIGN KEY (`userRole`) REFERENCES `tblrole` (`role_id`) ON DELETE SET NULL ON UPDATE CASCADE;
