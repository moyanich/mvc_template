
--
-- Indexes for dumped tables
--

--
-- Indexes for table `tblAddress`
--
ALTER TABLE `tblAddress`
  ADD PRIMARY KEY (`addressID`);

--
-- Indexes for table `tblContactNumbers`
--
ALTER TABLE `tblContactNumbers`
  ADD PRIMARY KEY (`phoneID`);

--
-- Indexes for table `tblContract`
--
ALTER TABLE `tblContract`
  ADD PRIMARY KEY (`contractID`),
  ADD UNIQUE KEY `contractType_UNIQUE` (`contractType`);

--
-- Indexes for table `tblDepartments`
--
ALTER TABLE `tblDepartments`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `deptID_UNIQUE` (`deptCode`),
  ADD UNIQUE KEY `deptName_UNIQUE` (`deptName`);

--
-- Indexes for table `tblEmailAddress`
--
ALTER TABLE `tblEmailAddress`
  ADD PRIMARY KEY (`emailID`);

--
-- Indexes for table `tblEmpAddress`
--
ALTER TABLE `tblEmpAddress`
  ADD PRIMARY KEY (`id`),
  ADD KEY `relAddressID` (`relAddressID`),
  ADD KEY `relEMPID_fk` (`relEMPID`),
  ADD KEY `relParishID` (`relParishID`);

--
-- Indexes for table `tblEmpContact`
--
ALTER TABLE `tblEmpContact`
  ADD PRIMARY KEY (`id`),
  ADD KEY `relEmpID_idx` (`relEmpID`),
  ADD KEY `relPhoneID_idx` (`relPhoneID`);

--
-- Indexes for table `tblEmpContract`
--
ALTER TABLE `tblEmpContract`
  ADD PRIMARY KEY (`id`),
  ADD KEY `relContractID` (`relContractID`),
  ADD KEY `eID` (`relEmpID`);

--
-- Indexes for table `tblEmpDepartment`
--
ALTER TABLE `tblEmpDepartment`
  ADD PRIMARY KEY (`id`),
  ADD KEY `relEmpIDFK` (`relEmpID`),
  ADD KEY `relDeptID` (`relDeptID`);

--
-- Indexes for table `tblEmpEmail`
--
ALTER TABLE `tblEmpEmail`
  ADD PRIMARY KEY (`id`),
  ADD KEY `relEmpID_idx` (`relEmpID`),
  ADD KEY `relEmailID_idx` (`relEmailID`);

--
-- Indexes for table `tblEmpJob`
--
ALTER TABLE `tblEmpJob`
  ADD PRIMARY KEY (`id`),
  ADD KEY `empID` (`relEmpID`),
  ADD KEY `jobID` (`relJobID`);

--
-- Indexes for table `tblEmpLeave`
--
ALTER TABLE `tblEmpLeave`
  ADD PRIMARY KEY (`idLeave`),
  ADD KEY `relLeaveID_idx` (`relLeaveID`),
  ADD KEY `eIDFK` (`relEmpID`);

--
-- Indexes for table `tblEmployees`
--
ALTER TABLE `tblEmployees`
  ADD PRIMARY KEY (`empID`),
  ADD UNIQUE KEY `id_UNIQUE` (`id`),
  ADD UNIQUE KEY `trn_UNIQUE` (`trn`),
  ADD UNIQUE KEY `nis_UNIQUE` (`nis`),
  ADD KEY `relGender_idx` (`relGender`);

--
-- Indexes for table `tblGender`
--
ALTER TABLE `tblGender`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tblJobs`
--
ALTER TABLE `tblJobs`
  ADD PRIMARY KEY (`jobID`);

--
-- Indexes for table `tblLeaveType`
--
ALTER TABLE `tblLeaveType`
  ADD PRIMARY KEY (`idType`),
  ADD UNIQUE KEY `leaveName_UNIQUE` (`leaveName`);

--
-- Indexes for table `tblParish`
--
ALTER TABLE `tblParish`
  ADD PRIMARY KEY (`parishID`),
  ADD UNIQUE KEY `parishName_UNIQUE` (`parishName`);

--
-- Indexes for table `tblrole`
--
ALTER TABLE `tblrole`
  ADD PRIMARY KEY (`roleID`,`roleName`),
  ADD UNIQUE KEY `role_name_UNIQUE` (`roleName`);

--
-- Indexes for table `tblUserLogs`
--
ALTER TABLE `tblUserLogs`
  ADD PRIMARY KEY (`idLogs`),
  ADD KEY `relUserID_idx` (`relUserID`);

--
-- Indexes for table `tbl_token_auth`
--
ALTER TABLE `tbl_token_auth`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`userID`),
  ADD UNIQUE KEY `username_UNIQUE` (`username`),
  ADD KEY `role_id_fk_idx` (`roleID`),
  ADD KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tblAddress`
--
ALTER TABLE `tblAddress`
  MODIFY `addressID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tblContactNumbers`
--
ALTER TABLE `tblContactNumbers`
  MODIFY `phoneID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tblContract`
--
ALTER TABLE `tblContract`
  MODIFY `contractID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tblDepartments`
--
ALTER TABLE `tblDepartments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `tblEmailAddress`
--
ALTER TABLE `tblEmailAddress`
  MODIFY `emailID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tblEmpAddress`
--
ALTER TABLE `tblEmpAddress`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tblEmpContract`
--
ALTER TABLE `tblEmpContract`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tblEmpDepartment`
--
ALTER TABLE `tblEmpDepartment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tblEmpEmail`
--
ALTER TABLE `tblEmpEmail`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tblEmpJob`
--
ALTER TABLE `tblEmpJob`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tblEmpLeave`
--
ALTER TABLE `tblEmpLeave`
  MODIFY `idLeave` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tblEmployees`
--
ALTER TABLE `tblEmployees`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tblGender`
--
ALTER TABLE `tblGender`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tblJobs`
--
ALTER TABLE `tblJobs`
  MODIFY `jobID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tblLeaveType`
--
ALTER TABLE `tblLeaveType`
  MODIFY `idType` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tblParish`
--
ALTER TABLE `tblParish`
  MODIFY `parishID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tblrole`
--
ALTER TABLE `tblrole`
  MODIFY `roleID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tblUserLogs`
--
ALTER TABLE `tblUserLogs`
  MODIFY `idLogs` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=233;

--
-- AUTO_INCREMENT for table `tbl_token_auth`
--
ALTER TABLE `tbl_token_auth`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `userID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tblEmpAddress`
--
ALTER TABLE `tblEmpAddress`
  ADD CONSTRAINT `relAddressID` FOREIGN KEY (`relAddressID`) REFERENCES `tblAddress` (`addressID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `relEMPID_fk` FOREIGN KEY (`relEMPID`) REFERENCES `tblEmployees` (`empID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `relParishID` FOREIGN KEY (`relParishID`) REFERENCES `tblParish` (`parishID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tblEmpContact`
--
ALTER TABLE `tblEmpContact`
  ADD CONSTRAINT `relEmpID` FOREIGN KEY (`relEmpID`) REFERENCES `tblEmployees` (`empID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `relPhoneID` FOREIGN KEY (`relPhoneID`) REFERENCES `tblContactNumbers` (`phoneID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tblEmpContract`
--
ALTER TABLE `tblEmpContract`
  ADD CONSTRAINT `eID` FOREIGN KEY (`relEmpID`) REFERENCES `tblEmployees` (`empID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `relContractID` FOREIGN KEY (`relContractID`) REFERENCES `tblContract` (`contractID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tblEmpDepartment`
--
ALTER TABLE `tblEmpDepartment`
  ADD CONSTRAINT `relDeptID` FOREIGN KEY (`relDeptID`) REFERENCES `tblDepartments` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `relEmpIDFK` FOREIGN KEY (`relEmpID`) REFERENCES `tblEmployees` (`empID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tblEmpEmail`
--
ALTER TABLE `tblEmpEmail`
  ADD CONSTRAINT `relEmailID` FOREIGN KEY (`relEmailID`) REFERENCES `tblEmailAddress` (`emailID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tblEmpJob`
--
ALTER TABLE `tblEmpJob`
  ADD CONSTRAINT `empID` FOREIGN KEY (`relEmpID`) REFERENCES `tblEmployees` (`empID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `jobID` FOREIGN KEY (`relJobID`) REFERENCES `tblJobs` (`jobID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tblEmpLeave`
--
ALTER TABLE `tblEmpLeave`
  ADD CONSTRAINT `eIDFK` FOREIGN KEY (`relEmpID`) REFERENCES `tblEmployees` (`empID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `relLeaveID` FOREIGN KEY (`relLeaveID`) REFERENCES `tblLeaveType` (`idType`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tblEmployees`
--
ALTER TABLE `tblEmployees`
  ADD CONSTRAINT `relGender` FOREIGN KEY (`relGender`) REFERENCES `tblGender` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tblemployees_ibfk_1` FOREIGN KEY (`empID`) REFERENCES `tblEmpEmail` (`relEmpID`);

--
-- Constraints for table `tblUserLogs`
--
ALTER TABLE `tblUserLogs`
  ADD CONSTRAINT `relUserID` FOREIGN KEY (`relUserID`) REFERENCES `users` (`userID`) ON UPDATE CASCADE;

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `usergroup` FOREIGN KEY (`roleID`) REFERENCES `tblrole` (`roleID`) ON DELETE NO ACTION ON UPDATE NO ACTION;
