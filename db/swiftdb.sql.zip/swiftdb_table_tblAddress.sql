
-- --------------------------------------------------------

--
-- Table structure for table `tblAddress`
--

CREATE TABLE `tblAddress` (
  `addressID` int(11) NOT NULL,
  `address1` varchar(45) DEFAULT NULL,
  `address2` varchar(45) DEFAULT NULL,
  `address3` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
