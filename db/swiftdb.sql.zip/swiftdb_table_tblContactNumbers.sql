
-- --------------------------------------------------------

--
-- Table structure for table `tblContactNumbers`
--

CREATE TABLE `tblContactNumbers` (
  `phoneID` int(11) NOT NULL,
  `contactNumbers` char(12) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
