
-- --------------------------------------------------------

--
-- Table structure for table `tblContract`
--

CREATE TABLE `tblContract` (
  `contractID` int(11) NOT NULL,
  `contractType` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
