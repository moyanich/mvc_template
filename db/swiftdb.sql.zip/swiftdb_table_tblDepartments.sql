
-- --------------------------------------------------------

--
-- Table structure for table `tblDepartments`
--

CREATE TABLE `tblDepartments` (
  `id` int(11) NOT NULL,
  `deptCode` char(6) NOT NULL,
  `deptName` varchar(45) NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_on` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tblDepartments`
--

INSERT INTO `tblDepartments` (`id`, `deptCode`, `deptName`, `created_date`, `modified_on`) VALUES
(1, 'dep1', 'Services', '2020-07-29 19:01:08', '2020-07-31 15:13:32'),
(2, 'dep8', 'Product Management Systems', '2020-07-29 19:01:09', '2020-07-31 17:10:15'),
(3, 'dep65', 'Samson', '2020-07-29 19:01:09', '2020-07-31 18:18:53'),
(4, 'dep4', 'Accounting Dept', '2020-07-29 19:01:09', '2020-07-30 19:44:51'),
(5, 'dep3', 'Information Technology', '2020-07-29 19:01:09', '2020-07-31 15:32:13'),
(6, 'dep7', 'Dentistry', '2020-08-04 14:45:00', NULL),
(7, 'B01', 'Bindery', '2020-08-04 14:45:54', NULL),
(8, 'IT03', 'Information Technology Plus', '2020-08-04 14:46:18', NULL),
(9, 'BIND', 'Bruseel', '2020-08-04 15:08:20', NULL);
