
-- --------------------------------------------------------

--
-- Table structure for table `tblEmailAddress`
--

CREATE TABLE `tblEmailAddress` (
  `emailID` int(11) NOT NULL,
  `emailAddress` varchar(45) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
