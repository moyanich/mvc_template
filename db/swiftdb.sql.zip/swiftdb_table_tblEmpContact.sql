
-- --------------------------------------------------------

--
-- Table structure for table `tblEmpContact`
--

CREATE TABLE `tblEmpContact` (
  `id` int(11) NOT NULL,
  `relEmpID` char(6) DEFAULT NULL,
  `relPhoneID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
