
-- --------------------------------------------------------

--
-- Table structure for table `tblEmpContract`
--

CREATE TABLE `tblEmpContract` (
  `id` int(11) NOT NULL,
  `relEmpID` char(6) NOT NULL,
  `relContractID` int(11) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date DEFAULT NULL,
  `created_at` varchar(45) NOT NULL DEFAULT 'CURRENT_TIMESTAMP'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
