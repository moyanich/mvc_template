
-- --------------------------------------------------------

--
-- Table structure for table `tblEmpDepartment`
--

CREATE TABLE `tblEmpDepartment` (
  `id` int(11) NOT NULL,
  `relEmpID` char(6) NOT NULL,
  `relDeptID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
