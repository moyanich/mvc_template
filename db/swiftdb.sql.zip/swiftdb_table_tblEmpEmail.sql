
-- --------------------------------------------------------

--
-- Table structure for table `tblEmpEmail`
--

CREATE TABLE `tblEmpEmail` (
  `id` int(11) NOT NULL,
  `relEmpID` char(6) NOT NULL,
  `relEmailID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
