
-- --------------------------------------------------------

--
-- Table structure for table `tblEmpJob`
--

CREATE TABLE `tblEmpJob` (
  `id` int(11) NOT NULL,
  `relEmpID` char(6) NOT NULL,
  `relJobID` int(11) NOT NULL,
  `relDeptID` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
