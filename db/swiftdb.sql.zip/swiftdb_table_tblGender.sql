
-- --------------------------------------------------------

--
-- Table structure for table `tblGender`
--

CREATE TABLE `tblGender` (
  `ID` int(11) NOT NULL,
  `Name` varchar(10) DEFAULT NULL,
  `Description` varchar(25) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
