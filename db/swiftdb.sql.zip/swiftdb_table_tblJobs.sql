
-- --------------------------------------------------------

--
-- Table structure for table `tblJobs`
--

CREATE TABLE `tblJobs` (
  `jobID` int(11) NOT NULL,
  `jobDesc` varchar(55) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
