
-- --------------------------------------------------------

--
-- Table structure for table `tblJobs`
--

CREATE TABLE `tblJobs` (
  `jobID` int(11) NOT NULL,
  `job` varchar(45) NOT NULL,
  `jobDesc` varchar(155) DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_at` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
