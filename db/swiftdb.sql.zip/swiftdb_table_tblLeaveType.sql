
-- --------------------------------------------------------

--
-- Table structure for table `tblLeaveType`
--

CREATE TABLE `tblLeaveType` (
  `idType` int(11) NOT NULL,
  `leaveName` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
