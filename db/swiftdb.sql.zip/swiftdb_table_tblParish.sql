
-- --------------------------------------------------------

--
-- Table structure for table `tblParish`
--

CREATE TABLE `tblParish` (
  `parishID` int(11) NOT NULL,
  `parishName` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
