
-- --------------------------------------------------------

--
-- Table structure for table `tblrole`
--

CREATE TABLE `tblrole` (
  `roleID` int(11) NOT NULL,
  `roleName` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tblrole`
--

INSERT INTO `tblrole` (`roleID`, `roleName`) VALUES
(1, 'Administrator'),
(4, 'Employee'),
(2, 'Super User'),
(5, 'Unregistered'),
(3, 'User');
